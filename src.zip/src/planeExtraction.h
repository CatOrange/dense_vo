#ifndef __PLANEEXTRACTION_H
#define __PLANEEXTRACTION_H

//#include <iostream>
//#include <cmath>
//#include <cstring>
//#include <stdio.h>
//#include <algorithm>
//#include <fstream>
//#include <vector>
//#include <list>
//#include "variableDefinition.h"
//#include "utility.h"
//#include "dataStructure.h"
//#include "opencv2/opencv.hpp"
//#include "opencv2/highgui/highgui.hpp"
//#include "opencv2/calib3d/calib3d.hpp"
//#include "opencv2/imgproc/imgproc.hpp"
//#include "opencv2/core/core.hpp"
//#include "opencv2/opencv.hpp"
//#include "opencv2/features2d/features2d.hpp"
////using namespace std;
////using namespace cv;
//
//void initGraph(unsigned short* depth, int height, int width, double fx, double fy, double cx, double cy);
//int planeExtraction(unsigned short* depth, int height, int width, double fx, double fy, double cx, double cy);
//void computeNormalByIntegral(unsigned short* depth, int height, int width, double fx, double fy, double cx, double cy);

#endif